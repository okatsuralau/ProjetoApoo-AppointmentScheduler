-- phpMyAdmin SQL Dump
-- version 4.0.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 15, 2014 at 09:07 AM
-- Server version: 5.1.44-community
-- PHP Version: 5.3.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tads_pds_scheduler`
--

-- --------------------------------------------------------

--
-- Table structure for table `civilstatus`
--

CREATE TABLE IF NOT EXISTS `civilstatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Estado Civil' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `civilstatus`
--

INSERT INTO `civilstatus` (`id`, `title`) VALUES
(1, 'Separado');

-- --------------------------------------------------------

--
-- Table structure for table `datebook`
--

CREATE TABLE IF NOT EXISTS `datebook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `office_id` int(11) NOT NULL,
  `health_plan_id` int(11) DEFAULT NULL,
  `appointment_time` datetime NOT NULL,
  `note` text COMMENT 'Observação (opcional)',
  `checkin` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`doctor_id`,`patient_id`),
  KEY `fk_datebook_doctors1_idx` (`doctor_id`),
  KEY `fk_datebook_patients1_idx` (`patient_id`),
  KEY `fk_datebook_office1_idx` (`office_id`),
  KEY `fk_datebook_health_plan1_idx` (`health_plan_id`),
  KEY `fk_datebook_exam1_idx` (`exam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Agenda de consultas' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `individual_id` int(11) NOT NULL,
  `expertise_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`individual_id`),
  KEY `fk_doctors_individuals1_idx` (`individual_id`),
  KEY `fk_doctors_expertise1_idx` (`expertise_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `educationlevel`
--

CREATE TABLE IF NOT EXISTS `educationlevel` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Nível de escolaridade';

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE IF NOT EXISTS `exam` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Exames médicos';

-- --------------------------------------------------------

--
-- Table structure for table `expertise`
--

CREATE TABLE IF NOT EXISTS `expertise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `expertise`
--

INSERT INTO `expertise` (`id`, `title`) VALUES
(1, 'Pediatras');

-- --------------------------------------------------------

--
-- Table structure for table `health_plan`
--

CREATE TABLE IF NOT EXISTS `health_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `individual`
--

CREATE TABLE IF NOT EXISTS `individual` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `skin_id` int(11) DEFAULT NULL,
  `educationlevel_id` int(11) DEFAULT NULL,
  `civilstatus_id` int(11) DEFAULT NULL,
  `cpf` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_individuals_skin1_idx` (`skin_id`),
  KEY `fk_individuals_education1_idx` (`educationlevel_id`),
  KEY `fk_individual_civilstatus1_idx` (`civilstatus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='registro único de pessoas' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE IF NOT EXISTS `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `record_id` int(11) NOT NULL,
  `model` varchar(30) NOT NULL,
  `activity` varchar(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ip` varchar(15) NOT NULL,
  `hostname` varchar(255) DEFAULT NULL,
  `timestamp_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`user_id`,`record_id`),
  KEY `fk_logs_users1_idx1` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `office`
--

CREATE TABLE IF NOT EXISTS `office` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `individual_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_patients_individuals1_idx` (`individual_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `queue`
--

CREATE TABLE IF NOT EXISTS `queue` (
  `id` int(11) NOT NULL,
  `datebook_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_queue_datebook1_idx` (`datebook_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Fila de espera para a consulta';

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE IF NOT EXISTS `record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `datebook_id` int(11) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`,`patient_id`,`datebook_id`),
  KEY `fk_records_patients1_idx` (`patient_id`),
  KEY `fk_record_datebook1_idx` (`datebook_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Prontuário médico do paciente (observações)' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `slug` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `title`, `slug`) VALUES
(1, 'Súper admin', 'superadmin'),
(2, 'Admin', 'admin'),
(3, 'titulo1', 'slug1'),
(4, 'novo registro', 'novo');

-- --------------------------------------------------------

--
-- Table structure for table `skin`
--

CREATE TABLE IF NOT EXISTS `skin` (
  `id` int(11) NOT NULL,
  `title` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `individual_id` int(11) NOT NULL DEFAULT '0',
  `role_id` int(11) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `passcode` varchar(64) NOT NULL,
  `activated` enum('0','1') NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`individual_id`),
  KEY `fk_users_individuals_idx` (`individual_id`),
  KEY `fk_users_role1_idx` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `datebook`
--
ALTER TABLE `datebook`
  ADD CONSTRAINT `fk_datebook_doctors1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_datebook_exam1` FOREIGN KEY (`exam_id`) REFERENCES `exam` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_datebook_health_plan1` FOREIGN KEY (`health_plan_id`) REFERENCES `health_plan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_datebook_office1` FOREIGN KEY (`office_id`) REFERENCES `office` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_datebook_patients1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `doctor`
--
ALTER TABLE `doctor`
  ADD CONSTRAINT `fk_doctors_expertise1` FOREIGN KEY (`expertise_id`) REFERENCES `expertise` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_doctors_individuals1` FOREIGN KEY (`individual_id`) REFERENCES `individual` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `individual`
--
ALTER TABLE `individual`
  ADD CONSTRAINT `fk_individuals_education1` FOREIGN KEY (`educationlevel_id`) REFERENCES `educationlevel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_individuals_skin1` FOREIGN KEY (`skin_id`) REFERENCES `skin` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_individual_civilstatus1` FOREIGN KEY (`civilstatus_id`) REFERENCES `civilstatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `fk_logs_users1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `fk_patients_individuals1` FOREIGN KEY (`individual_id`) REFERENCES `individual` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `queue`
--
ALTER TABLE `queue`
  ADD CONSTRAINT `fk_queue_datebook1` FOREIGN KEY (`datebook_id`) REFERENCES `datebook` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `record`
--
ALTER TABLE `record`
  ADD CONSTRAINT `fk_records_patients1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_record_datebook1` FOREIGN KEY (`datebook_id`) REFERENCES `datebook` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_users_individuals` FOREIGN KEY (`individual_id`) REFERENCES `individual` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_role1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
